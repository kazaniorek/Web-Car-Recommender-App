# The Code Created By Mariusz Soltycz Student Nr 30030295
# Original Dataset Dowloaded from github.com  created by HAJJARI (2023) 
# Importing necessary libraries for web application, data handling, and machine learning processing
from flask import Flask, request, render_template, jsonify
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os

# Set display options for pandas DataFrame outputs in the console
pd.set_option('display.max_row', 83)
pd.set_option('display.max_column', 83)


def load_data_and_attributes():
    """
    Load data from the CSV file containing car attributes and return a dictionary 
    containing unique values for various attributes.

    Returns:
    dict: A dictionary containing unique values for car attributes such as roofs, fuel types, models, brands,
          body types, gearboxes, upholsteries, power categories, and economy categories.
    """
    # Construct the file path to the CSV file    
    csv_file_path = os.path.join(os.path.dirname(__file__), 'Recommender_Cars_DF_Ready.csv')

     
    # Read the CSV file into a DataFrame   
    df = pd.read_csv(csv_file_path)

     # Create a dictionary containing unique values for various attributes
    return {
        'roofs': df['Roof'].dropna().unique(),
        'fuel_types': df['Energy/Fuel Type'].dropna().unique(),
        'models': df['Model'].dropna().unique(),
        'brands': df['Brand'].dropna().unique(),
        'body_types': df['Body Type'].dropna().unique(),
        'gearboxes': df['gearbox_select'].dropna().unique(),
        'upholsteries': df['Upholstery'].dropna().unique(),
        'power_categories': df['Power_Category'].dropna().unique(),
        'economy_categories': df['Economy_Category'].dropna().unique(),
        'pet_friendly': df['Pet Friendly'].dropna().unique()
    }

# Define a function to filter DataFrame based on price range
def filter_cars_by_price(df, min_price=None, max_price=None):
    # Apply minimum price filter if provided
    if min_price is not None:
        df = df[df['Price in GBP'] >= min_price]
    # Apply maximum price filter if provided
    if max_price is not None:
        df = df[df['Price in GBP'] <= max_price]
    
    # Check if the DataFrame is empty after applying filters
    if df.empty:
        print("No cars meet the specified price criteria.")
    
    return df


# Load data from a CSV file
csv_file_path = os.path.join(os.path.dirname(__file__), 'Recommender_Cars_DF_Ready.csv')
df = pd.read_csv(csv_file_path)

# Filtering DataFrame by price as set by variables min_price and max_price
min_price = None  # Minimum price set by the user
max_price = None  # Maximum price set by the user
df_cars = filter_cars_by_price(df, min_price=min_price, max_price=max_price)

# Select columns to use for feature extraction
chosen_columns = [
    'Brand', 'Model', 'Additional Info', 'Engine', 'Energy/Fuel Type', 'Engine Layout',
    'Engine Size (cc)', 'Maximum Power (HP)', 'Power_Category', 'Economy_Category',
    'Body Type', 'Gearbox', 'Upholstery', 'Roof', 'gearbox_select', 'Pet Friendly'
]

# Creating a new column 'features' in 'df_cars' which combines selected columns into a single string
df_cars['features'] = df_cars[chosen_columns].apply(lambda x: ' '.join(x.astype(str)), axis=1)

# Initialize TfidfVectorizer
tfv = TfidfVectorizer(min_df=3, max_features=None, strip_accents='unicode', analyzer='word', token_pattern=r'\w{1,}', ngram_range=(1, 3))
# Applying TfidfVectorizer to the 'features' column of 'df_cars'
tfv_matrix = tfv.fit_transform(df_cars['features'])


# Function to get brand loyalty recommendations based on the feature vectors
def get_brand_loyalty_recommendations(brand_query=None, model_query=None, body_type=None, fuel_type=None, engine_query=None,
                                      power_category=None, economy_category=None, gearbox=None, upholstery=None,
                                      roof=None, pet_friendly=False, df_cars=df_cars, top_n=20):
    """
    Generates brand loyalty recommendations based on various filters and a similarity score.
    """
    scores_df = pd.DataFrame({'score': np.zeros(len(df_cars))}, index=df_cars.index)

    # Update scores based on brand or model query if provided

    if brand_query and brand_query.strip():
        brand_similarity_indices = df_cars['Brand'].str.lower() == brand_query.lower()
        scores_df.loc[brand_similarity_indices, 'score'] += 0.4

    if model_query and model_query.strip():
        model_similarity_indices = df_cars['Model'].str.lower() == model_query.lower()
        scores_df.loc[model_similarity_indices, 'score'] += 0.2


    # Boosting scores based on additional filters
    if fuel_type and fuel_type.strip():
        fuel_boost_indices = df_cars['Energy/Fuel Type'].str.lower() == fuel_type.lower()
        scores_df.loc[fuel_boost_indices, 'score'] += 0.15

    if engine_query and engine_query.strip():
        engine_info = df_cars['Engine'].apply(lambda x: x if engine_query.lower() in x.lower() else '')
        engine_match_indices = engine_info != ''
        scores_df.loc[engine_match_indices, 'score'] += 0.1

    # Continue with other conditions
    if power_category and power_category.strip():
        power_category_indices = df_cars['Power_Category'].str.lower() == power_category.lower()
        scores_df.loc[power_category_indices, 'score'] += 0.1

    if economy_category and economy_category.strip():
        economy_category_indices = df_cars['Economy_Category'].str.lower() == economy_category.lower()
        scores_df.loc[economy_category_indices, 'score'] += 0.1

    if body_type and body_type.strip():
        body_type_indices = df_cars['Body Type'].str.lower() == body_type.lower()
        scores_df.loc[body_type_indices, 'score'] += 0.1

    if gearbox and gearbox.strip():
        gearbox_indices = df_cars['gearbox_select'].str.lower() == gearbox.lower()
        scores_df.loc[gearbox_indices, 'score'] += 0.2

    if upholstery and upholstery.strip():
        upholstery_indices = df_cars['Upholstery'].str.lower() == upholstery.lower()
        scores_df.loc[upholstery_indices, 'score'] += 0.1

    if roof and roof.strip():
        roof_indices = df_cars['Roof'].str.lower() == roof.lower()
        scores_df.loc[roof_indices, 'score'] += 0.2

    if pet_friendly and pet_friendly.strip():
        pet_friendly_indices = df_cars['Pet Friendly'].str.lower() == pet_friendly.lower()
        scores_df.loc[pet_friendly_indices, 'score'] += 0.5          

    # Selecting the top recommendations based on score
    top_scores_indices = scores_df['score'].nlargest(top_n).index
    recommendations = df_cars.loc[top_scores_indices]
    recommendations['similarity_score'] = scores_df['score'].loc[top_scores_indices]

    return recommendations




# Function to evaluate how well a car matches with a user's profile
def evaluate_car_match(user, car):
    """
    Evaluates the suitability of a car based on the user's profile preferences.
    """
    score = 0

    family_size = int(user.get('FamilySize')) if user.get('FamilySize') else None
    num_seats = int(car['Number of Seats']) if car['Number of Seats'] else 0
    if family_size is not None and num_seats < family_size:
        return -1  # Return a negative score to exclude the car

    # Definitions of preferred body types for various user profiles
    preferred_body_types_for_large_family = ['Family SUV', 'Compact SUV', 'Limousine', 'Sedan Coupe', 'Three-door Sedan', 'Two-door Sedan', 'Utility']
    preferred_body_types_for_small_family = ['Two-door Compact', 'Three-door Compact', 'Compact SUV']
    urban_preferred_body_types = ['Compact SUV', 'Two-door Compact', 'Family SUV', 'Three-door Compact', 'Two-door Sedan', 'Sedan Coupe', 'Three-door Sedan', 'Limousine']
    town_preferred_body_types = ['Compact SUV', 'Two-door Compact', 'Family SUV', 'Three-door Compact', 'Two-door Sedan', 'Sedan Coupe', 'Three-door Sedan', 'Utility']
    farm_preferred_body_types = ['Utility', 'Family SUV']
    pet_owner_preferred_body_types = ['Utility', 'Family SUV', 'Compact SUV']

    body_type = car.get('Body Type', '')
    if family_size is not None:
        if family_size >= 4 and body_type in preferred_body_types_for_large_family:
            score += 2
        elif family_size < 4 and body_type in preferred_body_types_for_small_family:
            score += 1

    where_they_live = user.get('WhereTheyLive', 'None')
    if where_they_live == 'city' and body_type in urban_preferred_body_types:
        score += 1
        print(f"Added pet score, new score: {score}")
    elif where_they_live == 'town' and body_type in town_preferred_body_types:
        score += 1
        print(f"Added pet score, new score: {score}")
    elif where_they_live == 'farm' and body_type in farm_preferred_body_types:
        score += 3
        print(f"Added pet score, new score: {score}")

    pets = user.get('Pets', 'None')
    if pets == 'yes' and body_type in pet_owner_preferred_body_types:
        score += 10
        print(f"Added pet score, new score: {score}")

    traveling_style = user.get('TravelingStyle', 'None')
    city_mpg = car.get('City Consumption (MPG)', 0)
    if traveling_style == 'city' and city_mpg > 40:
        score += 2
        print(f"Added pet score, new score: {score}")
    elif traveling_style == 'motorway' and car.get('Highway Consumption (MPG)', 0) > 45:
        score += 2
        print(f"Added pet score, new score: {score}")
    elif traveling_style == 'combined' and car.get('Combined Consumption (MPG)', 0) > car.get('City Consumption (MPG)', 0) + 5:
        score += 2
        print(f"Added pet score, new score: {score}")
    print(f"Calculated score: {score}")

    return score


# Function to recommend cars based on the user profile and the match score
def recommend_cars_for_user(user, cars_with_scores):
    """
    Recommends cars based on calculated match scores and existing similarity scores.

    Parameters:
    - user (dict): Dictionary containing user's profile information.
    - cars_with_scores (DataFrame): DataFrame of cars with initial scores (like similarity scores).

    Returns:
    - DataFrame: Sorted DataFrame of cars recommended based on the final score combining match and similarity scores.
    """

    # Calculate 'match score' using the evaluate_car_match function for each car
    cars_with_scores['match_score'] = cars_with_scores.apply(lambda car: evaluate_car_match(user, car), axis=1)

    # Incorporate 'similarity_score' into the final score calculation, if available
    if 'similarity_score' in cars_with_scores.columns:
        cars_with_scores['final_score'] = (cars_with_scores['similarity_score'] * 0.5) + (
                    cars_with_scores['match_score'] * 0.5)
    else:
        cars_with_scores['final_score'] = cars_with_scores[
            'match_score']  # Use match_score as final_score if no similarity_score

    # Sort the cars based on the final score in descending order to get the top recommendations
    recommended_cars = cars_with_scores.sort_values(by='final_score', ascending=False).head(10)

    return recommended_cars


# Function to display recommendations in an HTML format
def display_recommendations(recommendations, title, additional_columns=[]):

    # Check if the input is a DataFrame
    if isinstance(recommendations, pd.DataFrame):
        if recommendations.empty:
            return f"<h3>{title}</h3><p>No recommendations available.</p>"
        # Define columns to display and include any additional columns specified
        columns_to_display = [
                                 'Brand', 'Model', 'Additional Info', 'Energy/Fuel Type', 'Engine', 'Engine Size (cc)',
                                 'Body Type', 'City Consumption (MPG)', 'Highway Consumption (MPG)',
                                 'Combined Consumption (MPG)', 'Gearbox', 'Maximum Power (HP)', 'Maximum Torque (Nm)',
                                 'Number of Seats', 'Acceleration 0-60 mph in seconds', 'Top Speed (mph)',
                                 'Upholstery', 'Roof', 'Price in GBP'
                             ] + additional_columns


        # Generate HTML table from the DataFrame with the columns specified, limited to the top 10 recommendations
        html_output = f"<h3>{title}</h3>"
        html_output += recommendations.head(10)[columns_to_display].to_html(classes='table table-striped', index=False)
        return html_output
    else:
        # If not a DataFrame, return the string as an error message or info
        return f"<h3>{title}</h3><p>{recommendations}</p>"


# Function to calculate and display final consolidated recommendations based on combined scores
def calculate_and_display_final_recommendations(brand_loyalty_recs, profile_based_recs):
    """
    Calculates the final recommendations by averaging the similarity and match scores,
    sorts them by the final score, and then generates an HTML representation for display.

    Parameters:
    - brand_loyalty_recs (DataFrame): DataFrame containing brand loyalty recommendations.
    - profile_based_recs (DataFrame): DataFrame containing profile-based recommendations.

    Returns:
    - str: HTML content of the top recommendations based on the final score.
    """

    # Create a new DataFrame to calculate the final score
    final_recommendations = profile_based_recs.copy()
    final_recommendations['final_score'] = (final_recommendations['similarity_score'] + final_recommendations[
        'match_score']) / 2

    # Sorting the final recommendations by 'final_score' in descending order to get the best recommendations at the top
    final_recommendations_sorted = final_recommendations.sort_values(by='final_score', ascending=False)

    # Generate HTML for the top 20 recommendations, including the calculated scores
    return display_recommendations(final_recommendations_sorted.head(20), "Final Consolidated Recommendations",
                                   ['similarity_score', 'match_score', 'final_score'])



# Main function that integrates all recommendation steps into a complete system
def integrated_recommendation_system(df_cars, brand_query=None, model_query=None, body_type=None, fuel_type=None, engine_query=None,
                                     power_category=None, economy_category=None, gearbox=None, upholstery=None,
                                     roof=None, pet_friendly=None, user_profile=None):
    """
    Integrates various recommendation steps to provide a comprehensive recommendation system based on user inputs and car data.

    Parameters:
    - df_cars (DataFrame): The main DataFrame containing car data.
    - brand_query (str, optional): Query for brand .
    - model_query (str, optional): Query for model .
    - body_type (str, optional): Preferred body type.
    - fuel_type (str, optional): Preferred fuel type.
    - engine_query (str, optional): Specific engine characteristics query.
    - power_category (str, optional): Desired power category.
    - economy_category (str, optional): Desired economy category.
    - gearbox (str, optional): Preferred type of gearbox.
    - upholstery (str, optional): Preferred upholstery.
    - roof (str, optional): Preferred roof type.
    - pet_friendly (str, optional): Pet friendly or not.
    - user_profile (dict, optional): Dictionary containing user profile details like family size, job, etc.

    Returns:
    - Tuple[DataFrame, DataFrame, DataFrame]: Returns a tuple of DataFrames for brand loyalty recommendations,
      profile-based recommendations, and final recommendations.
    """
    # Stage 1: Brand Loyalty Recommendations
    if brand_query or model_query or body_type or fuel_type or engine_query or power_category or economy_category or gearbox or upholstery or roof or pet_friendly:
        brand_loyalty_recommendations = get_brand_loyalty_recommendations(brand_query, model_query, body_type, fuel_type,
                                                                          engine_query, power_category,
                                                                          economy_category, gearbox, upholstery, roof, pet_friendly,
                                                                          df_cars, top_n=20)
    else:
        brand_loyalty_recommendations = df_cars.copy()
        brand_loyalty_recommendations['similarity_score'] = 0  # Initialize with zero similarity score for uniformity

    # Stage 2: Profile-based Recommendations
    if user_profile:
        profile_based_recommendations = recommend_cars_for_user(user_profile, brand_loyalty_recommendations)
        if 'match_score' not in profile_based_recommendations.columns:
            profile_based_recommendations['match_score'] = 0  # Ensure column exists even if no scores were computed
    else:
        profile_based_recommendations = brand_loyalty_recommendations.copy()
        profile_based_recommendations['match_score'] = 0  # Ensure column exists

    # Stage 3: Calculating Final Recommendations
    final_recommendations = calculate_and_display_final_recommendations(brand_loyalty_recommendations,
                                                                        profile_based_recommendations)

    return brand_loyalty_recommendations, profile_based_recommendations, final_recommendations


# Initialize the Flask application
app = Flask(__name__)

@app.route('/recommend_form')
def recommend_form():
    attributes = load_data_and_attributes()
    return render_template('recommend_form.html', attributes=attributes)


# Define the route for the home page
@app.route('/')
def home():
    attributes = load_data_and_attributes()  # Load attributes from the helper function
    return render_template('index.html', attributes=attributes)

# Define the route for a specific functionality
# df_cars loaded within the function
df_cars = filter_cars_by_price(df, min_price=min_price, max_price=max_price)

def get_user_profile():
    # Retrieve user data from the request arguments
    return {
        'FamilySize': request.args.get('familySize', type=int),
        'WhereTheyLive': request.args.get('whereTheyLive', default='None', type=str),
        'Pets': request.args.get('pets', default='yes', type=str),
        'TravelingStyle': request.args.get('travelingStyle', default='None', type=str)
    }

# Define a route for a specific functionality, '/some_route'
@app.route('/some_route')
def some_route():
    # Retrieve user profile information using the 'get_user_profile' function
    user_profile = get_user_profile()
    try:
        # Integrate the recommendation system using the 'integrated_recommendation_system' function
        recommendation_sets = integrated_recommendation_system(df_cars, brand_query="", user_profile=user_profile)

        # Define titles for different sets of recommendations
        titles = ["Brand Loyalty Recommendations", "User Profile Recommendations", "Final Recommendations"]

        # Generate HTML representations for the recommendation sets using 'display_recommendations' function
        recommendations_html = ''.join(display_recommendations(rec, title) for rec, title in zip(recommendation_sets, titles))

        # Render the HTML template 'some_template.html' with the generated recommendations
        return render_template('some_template.html', recommendations_html=recommendations_html)
    
    # Handle exceptions and return an error response if encountered
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Define a route to handle recommendations based on user input from a form on the website
@app.route('/recommend', methods=['POST'])
def recommend():
    # Retrieve form data
    brand = request.form.get('brand') or "No preference"
    model = request.form.get('model') or "No preference"
    fuel_type = request.form.get('fuel_type') or "No preference"
    body_type = request.form.get('body_type') or "No preference"
    gearbox = request.form.get('gearbox') or "No preference"
    upholstery = request.form.get('upholstery') or "No preference"
    power_category = request.form.get('power_category') or "No preference"
    economy_category = request.form.get('economy_category') or "No preference"
    roof = request.form.get('roof') or "No preference"
    pet_friendly = request.form.get('pet_friendly') or "No preference"
    engine = request.form.get('engine_query', '').strip().lower() or "No preference"
    min_price = request.form.get('min_price', type=float)
    max_price = request.form.get('max_price', type=float)

    # User profile data
    family_size = request.form.get('familySize')
    where_they_live = request.form.get('whereTheyLive')
    pets = request.form.get('pets')
    traveling_style = request.form.get('travelingStyle')

    # Creating a dictionary of all user choices for displaying in the template
    user_choices = {
        'brand': brand,
        'model': model,
        'engine': engine,
        'fuel_type': fuel_type,
        'body_type': body_type,
        'gearbox': gearbox,
        'upholstery': upholstery,
        'power_category': power_category,
        'economy_category': economy_category,
        'roof': roof,
        'pet_friendly': pet_friendly,
        'min_price': f"£{min_price:,.0f}" if min_price else "No lower limit",
        'max_price': f"£{max_price:,.0f}" if max_price else "No upper limit",
        'family_size': family_size or "No preference",
        'where_they_live': where_they_live or "No preference",
        'pets': pets or "No preference",
        'traveling_style': traveling_style or "No preference"
    }

    # Filter the DataFrame by price range
    df_cars = filter_cars_by_price(df, min_price=min_price, max_price=max_price)
    if df_cars.empty:
        return render_template('recommendations.html', message="No cars meet the specified price criteria.", user_choices=user_choices)

    # Generate recommendations
    recommendation_sets = integrated_recommendation_system(
        df_cars,
        brand_query=brand,
        model_query=model,
        body_type=body_type,
        fuel_type=fuel_type,
        gearbox=gearbox,
        upholstery=upholstery,
        power_category=power_category,
        economy_category=economy_category,
        roof=roof,
        pet_friendly=pet_friendly,
        engine_query=engine,
        user_profile={
            'FamilySize': family_size,
            'WhereTheyLive': where_they_live,
            'Pets': pets,
            'TravelingStyle': traveling_style
        }
    )

    # Define titles for different recommendation sets
    final_recommendations = recommendation_sets[2]  # Index 2 for "Final Recommendations", adjust as needed

    # Generate HTML for final recommendations
    final_recommendations_html = display_recommendations(final_recommendations, "The very top car is the most recommended. The rest are similar recommendations.")

    # Return the rendered HTML template with the final recommendation content
    return render_template('recommendations.html', final_recommendations_html=final_recommendations_html, user_choices=user_choices)


if __name__ == '__main__':
    """
    This block is the entry point of the Flask application when run directly from the Python script.
    It runs the Flask application on the local development server.

    - 'debug=True' is set to enable Flask's debugger, which provides a web-based interface for debugging the application on errors.
    """
    app.run(debug=True)
